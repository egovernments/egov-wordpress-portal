jQuery(document).ready(function ($) {
	$("#wp-version-message").after("<p>Running PHP version: <b style='color:green;'>" + dpvObj.phpVersion + "</b></p>");
});